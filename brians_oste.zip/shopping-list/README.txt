A Pen created at CodePen.io. You can find this one at http://codepen.io/markmurray/pen/aCfiF.

 A Simple Shopping List and Inventory built with AngularJS 